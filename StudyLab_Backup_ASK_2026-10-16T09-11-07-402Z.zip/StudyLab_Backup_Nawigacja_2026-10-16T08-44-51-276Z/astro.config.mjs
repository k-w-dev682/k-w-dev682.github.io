
import { defineConfig } from 'astro/config';
import starlight from '@astrojs/starlight';
import react from '@astrojs/react';

export default defineConfig({
  integrations: [
    starlight({
      title: 'StudyLab',

      customCss: ['./src/styles/custom.css'],

      sidebar: [
        {
          label: 'Programowanie C++',
          items: [
            { autogenerate: { directory: 'programowanie' } },
          ],
        },
        {
          label: 'Matematyka',
          items: [
            { autogenerate: { directory: 'matematyka' } },
          ],
        },
      ],
    }),
    react(),
  ],
});
