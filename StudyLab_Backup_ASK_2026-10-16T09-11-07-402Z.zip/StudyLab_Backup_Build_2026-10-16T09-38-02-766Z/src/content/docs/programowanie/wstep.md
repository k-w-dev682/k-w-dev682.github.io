---
title: Wprowadzenie do C++
description: Co robi program i od czego zacząć naukę C++?
sidebar:
  order: 1
---

# Wprowadzenie do C++

Zacznijmy od najważniejszej myśli: **program jest listą precyzyjnych instrukcji dla komputera**. Komputer nie odgaduje, co mieliśmy na myśli — wykonuje to, co zostało zapisane w kodzie.

## Pierwszy program

```cpp
#include <iostream>

int main() {
    std::cout << "Witaj w StudyLab!\n";
    return 0;
}
```

| Fragment | Co oznacza? |
|---|---|
| `#include <iostream>` | Umożliwia korzystanie z wejścia i wyjścia tekstowego. |
| `int main()` | Funkcja, od której zaczyna się wykonanie programu. |
| `{` oraz `}` | Początek i koniec bloku instrukcji. |
| `std::cout` | Strumień standardowego wyjścia; zwykle wypisuje tekst w konsoli. |
| `<<` | Przesyła wartość do strumienia wyjściowego. |
| `"..."` | Tekst, czyli literał napisowy. |
| `\n` | Znak przejścia do nowego wiersza. |
| `;` | Kończy daną instrukcję. |
| `return 0;` | Zwraca z `main` kod oznaczający pomyślne zakończenie. |

## Ważne rozróżnienie

**Kod źródłowy** to tekst w pliku `.cpp`. **Program wykonywalny** powstaje po kompilacji i linkowaniu. Więcej na ten temat w [lekcji o kompilacji](../kompilacja/).

## Zmienna — miejsce na wartość

```cpp
int wiek = 19;
wiek = wiek + 1;
std::cout << wiek; // 20
```

Pierwsza linia tworzy zmienną `wiek` i ustawia ją na 19. Druga **nie jest równaniem matematycznym**: najpierw oblicza prawą stronę (`19 + 1`), a następnie zapisuje wynik z powrotem do zmiennej.

:::tip[Jak pracować z lekcjami]
Najpierw przeczytaj wyjaśnienie, potem samodzielnie przewidź wynik kodu. Dopiero później uruchom interaktywną symulację i sprawdź odpowiedź.
:::

## Mapa działu

- [Kompilacja i budowanie programu](../kompilacja/)
- [Pętle `while` i `for`](../petle/)
- [Debugowanie krok po kroku](../debugger/)
- [Typy `float` i `double`](../liczby-zmiennoprzecinkowe/)
- [Znaki `char` i napisy `string`](../znaki-i-napisy/)
- [Wszystkie interaktywne laboratoria](../laboratorium/)

> Opracowanie dydaktyczne oparte na czterech dostarczonych skryptach z ćwiczeń. Przykłady zostały uproszczone i przepisane własnymi słowami; nie jest to dosłowna kopia materiałów prowadzącego.
