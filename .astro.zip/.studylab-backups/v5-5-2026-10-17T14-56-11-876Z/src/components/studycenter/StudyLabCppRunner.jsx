import React, { useCallback, useEffect, useRef, useState } from 'react';
import './studylab-cpp-runner.css';

// The compiler itself lives in public/clang/ (Clang 22 / WASI, compiled to WebAssembly).
// No program source is sent to an external execution API.
const DEFAULT_PROGRAM = `#include <iostream>
using namespace std;

int main() {
    int a, b;
    cout << "Podaj dwie liczby: ";
    cin >> a >> b;
    cout << "Suma: " << a + b << '\\n';
    return 0;
}
`;

const TASKS = [
  { id: 'sum', title: 'Suma liczb od 1 do n', description: 'Napisz funkcję int suma(int n). Dla n >= 0 zwróć sumę liczb całkowitych od 1 do n.', template: 'int suma(int n) {\n    // Napisz rozwiazanie\n    return 0;\n}\n', tip: 'Zacznij od int wynik = 0. Dodawaj kolejne liczby od 1 do n i zwróć wynik.', tests: [{ args: '0', expected: '0' }, { args: '1', expected: '1' }, { args: '3', expected: '6' }, { args: '10', expected: '55' }] },
  { id: 'even', title: 'Parzysta czy nie?', description: 'Napisz funkcję bool czyParzysta(int n).', template: 'bool czyParzysta(int n) {\n    // Napisz rozwiazanie\n    return false;\n}\n', tip: 'Jeśli n % 2 == 0, liczba jest parzysta. Zwróć wynik porównania.', tests: [{ args: '0', expected: '1' }, { args: '2', expected: '1' }, { args: '7', expected: '0' }, { args: '-4', expected: '1' }] },
  { id: 'max', title: 'Maksimum dwóch liczb', description: 'Napisz funkcję int maksimum(int a, int b).', template: 'int maksimum(int a, int b) {\n    // Napisz rozwiazanie\n    return 0;\n}\n', tip: 'Użyj if (a > b) return a; a w przeciwnym razie return b;', tests: [{ args: '2, 5', expected: '5' }, { args: '8, 3', expected: '8' }, { args: '4, 4', expected: '4' }, { args: '-7, -2', expected: '-2' }] },
  { id: 'factorial', title: 'Silnia', description: 'Napisz funkcję long long silnia(int n), przyjmując 0 <= n <= 20.', template: 'long long silnia(int n) {\n    // Napisz rozwiazanie\n    return 0;\n}\n', tip: 'Wynik rozpocznij od 1. Dla i od 2 do n mnoż wynik przez i.', tests: [{ args: '0', expected: '1' }, { args: '1', expected: '1' }, { args: '4', expected: '24' }, { args: '7', expected: '5040' }, { args: '10', expected: '3628800' }] },
];

const FUNCTION_NAMES = { sum: 'suma', even: 'czyParzysta', max: 'maksimum', factorial: 'silnia' };
const STANDARDS = ['gnu++11', 'gnu++14', 'gnu++17', 'gnu++20', 'gnu++23'];
const RUN_LIMIT_MS = 60000;
const safeLoad = (key, fallback) => { try { return localStorage.getItem(key) ?? fallback; } catch { return fallback; } };
const safeSave = (key, value) => { try { localStorage.setItem(key, value); } catch { /* blocked by browser */ } };
const codeKey = (view, id) => `studylab-cpp-wasm-v1:${view}:${id}`;

function makeHarness(code, task) {
  if (/\b(?:int|auto|void)\s+main\s*\(/.test(code)) throw new Error('W zadaniu wpisz tylko funkcję (bez main). StudyLab sam doda main() do testów.');
  const fname = FUNCTION_NAMES[task.id];
  if (!fname) throw new Error('Nieznane zadanie.');
  const tests = task.tests.map((item, index) => `    std::cout << "STUDYLAB_TEST_${index}:" << (${fname}(${item.args})) << "\\n";`).join('\n');
  return `${code}\n#include <iostream>\nint main() {\n${tests}\n    return 0;\n}\n`;
}
function readTestResults(stdout, task) {
  const outputs = new Map();
  for (const line of String(stdout).split(/\r?\n/)) {
    const m = line.trim().match(/^STUDYLAB_TEST_(\d+):(.*)$/);
    if (m) outputs.set(Number(m[1]), m[2].trim());
  }
  return task.tests.map((test, index) => ({ ...test, received: outputs.get(index) ?? 'brak wyniku', pass: outputs.get(index) === test.expected }));
}

export default function StudyLabCppRunner({ onAttempt }) {
  const [view, setView] = useState('free');
  const [taskId, setTaskId] = useState('sum');
  const [code, setCode] = useState(() => safeLoad(codeKey('free', 'main'), DEFAULT_PROGRAM));
  const [stdin, setStdin] = useState(() => safeLoad('studylab-cpp-wasm-v1:stdin', '5 7\n'));
  const [standard, setStandard] = useState(() => safeLoad('studylab-cpp-wasm-v1:standard', 'gnu++17'));
  const [phase, setPhase] = useState('idle');
  const [progress, setProgress] = useState(0);
  const [message, setMessage] = useState('Wybierz „Uruchom kod”, aby skompilować go w przeglądarce.');
  const [result, setResult] = useState(null);
  const [showTip, setShowTip] = useState(false);
  const [runCount, setRunCount] = useState(0);
  const workerRef = useRef(null);
  const timerRef = useRef(null);
  const serialRef = useRef(0);
  const currentRef = useRef(null);
  const onAttemptRef = useRef(onAttempt);
  onAttemptRef.current = onAttempt;
  const active = ['loading', 'compiling', 'running'].includes(phase);
  const task = TASKS.find(t => t.id === taskId) || TASKS[0];

  useEffect(() => { safeSave(codeKey(view, view === 'free' ? 'main' : taskId), code); }, [code, view, taskId]);
  useEffect(() => { safeSave('studylab-cpp-wasm-v1:stdin', stdin); }, [stdin]);
  useEffect(() => { safeSave('studylab-cpp-wasm-v1:standard', standard); }, [standard]);
  useEffect(() => () => { serialRef.current += 1; clearTimeout(timerRef.current); workerRef.current?.terminate(); workerRef.current = null; }, []);

  const terminate = useCallback((status = 'stopped') => {
    serialRef.current += 1;
    clearTimeout(timerRef.current);
    workerRef.current?.terminate();
    workerRef.current = null;
    currentRef.current = null;
    setPhase(status);
    setMessage(status === 'timeout'
      ? 'Przekroczono limit 60 sekund od rozpoczęcia kompilacji. Proces został zatrzymany. Możesz uruchomić go ponownie.'
      : 'Zatrzymano kompilację lub program.');
  }, []);

  const switchTo = (nextView, nextTaskId = taskId) => {
    if (active) terminate();
    setView(nextView);
    setTaskId(nextTaskId);
    const chosen = TASKS.find(t => t.id === nextTaskId) || TASKS[0];
    setCode(safeLoad(codeKey(nextView, nextView === 'free' ? 'main' : nextTaskId), nextView === 'free' ? DEFAULT_PROGRAM : chosen.template));
    setShowTip(false);
    setResult(null);
    setPhase('idle');
    setMessage('Kod gotowy do uruchomienia.');
  };

  const run = useCallback(() => {
    if (active) return;
    if (!code.trim()) { setPhase('error'); setMessage('Najpierw wpisz kod C++.'); return; }
    let source = code;
    if (view === 'task') {
      try { source = makeHarness(code, task); }
      catch (e) { setPhase('error'); setMessage(e.message); return; }
    }
    const runId = serialRef.current + 1;
    serialRef.current = runId;
    clearTimeout(timerRef.current);
    workerRef.current?.terminate();
    workerRef.current = null;
    currentRef.current = { view, task, onAttempt: onAttemptRef.current };
    setResult(null);
    setPhase('loading');
    setProgress(0);
    setMessage('Przygotowywanie kompilatora Clang w WebAssembly… przy pierwszym uruchomieniu pobierze około 29 MB.');
    try {
      // BASE_URL works both on localhost and when Astro is hosted in a GitHub Pages subdirectory.
      const base = import.meta.env.BASE_URL || '/';
      const workerUrl = new URL(`${base.replace(/\/$/, '')}/clang/studylab-cpp.worker.js`, window.location.origin);
      const worker = workerRef.current || new Worker(workerUrl);
      workerRef.current = worker;
      worker.onmessage = (event) => {
        if (serialRef.current !== runId) return;
        const msg = event.data || {};
        if (msg.type === 'progress') {
          setProgress(Number(msg.value) || 0);
          setMessage('Pobieranie i inicjalizacja kompilatora: ' + Math.round((Number(msg.value) || 0) * 100) + '%');
        } else if (msg.type === 'ready') {
          setPhase('compiling');
          setMessage('Kompilowanie kodu przez Clang…');
          clearTimeout(timerRef.current);
          timerRef.current = setTimeout(() => terminate('timeout'), RUN_LIMIT_MS);
        } else if (msg.type === 'finished') {
          clearTimeout(timerRef.current);
          const data = msg.result || {};
          const compiled = Number.isInteger(data.exitCode);
          const tests = currentRef.current?.view === 'task' && compiled ? readTestResults(data.stdout, currentRef.current.task) : null;
          const allPass = Array.isArray(tests) && tests.every(item => item.pass);
          setResult({ ...data, tests, allPass });
          setPhase(compiled ? 'done' : 'error');
          setMessage(!compiled ? 'Błąd kompilacji lub linkowania — sprawdź komunikaty poniżej.' : tests ? `Testy: ${tests.filter(t => t.pass).length}/${tests.length} poprawnych.` : 'Program wykonany. Kod wyjścia: ' + data.exitCode);
          setRunCount(n => n + 1);
          if (tests && typeof currentRef.current?.onAttempt === 'function') {
            const info = currentRef.current;
            try {
              info.onAttempt({ id: `plus-cpp-wasm-${info.task.id}-${Date.now()}-${runId}`, subject: 'cpp', topic: `plus-cpp-wasm-${info.task.id}`, question: info.task.description, given: tests.map((t,i) => `${i + 1}:${t.received}`).join(', ').slice(0,400), answer: tests.map((t,i) => `${i + 1}:${t.expected}`).join(', ').slice(0,400), why: `Rzeczywisty Clang/WASM, testy: ${tests.filter(t => t.pass).length}/${tests.length}`, ok: allPass, mode: 'plus-cpp-wasm', hints: showTip ? 1 : 0, date: Date.now() });
            } catch (e) { /* An analytics failure must never hide the compiler result. */ }
          }
        } else if (msg.type === 'failed') {
          clearTimeout(timerRef.current);
          setPhase('error');
          setMessage(String(msg.message || 'Nie udało się uruchomić kompilatora.'));
        }
      };
      worker.onerror = (event) => {
        if (serialRef.current !== runId) return;
        clearTimeout(timerRef.current);
        worker.terminate();
        if (workerRef.current === worker) workerRef.current = null;
        setPhase('error');
        setMessage('Błąd ładowania Workera: ' + (event.message || 'Sprawdź, czy public/clang/ zostało zainstalowane.'));
      };
      worker.postMessage({ type: 'run', source, stdin: view === 'task' ? '' : stdin, standard });
    } catch (e) { clearTimeout(timerRef.current); workerRef.current?.terminate(); workerRef.current = null; setPhase('error'); setMessage('Nie można uruchomić kompilatora: ' + (e.message || String(e))); }
  }, [active, code, view, task, stdin, standard, terminate, showTip]);

  const download = () => {
    const blob = new Blob([code], { type: 'text/x-c++src;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a'); link.href = url; link.download = view === 'free' ? 'main.cpp' : `${taskId}.cpp`;
    document.body.appendChild(link); link.click(); link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  };
  const onCodeKeyDown = (event) => {
    if ((event.ctrlKey || event.metaKey) && event.key === 'Enter') { event.preventDefault(); run(); }
    if (event.key === 'Tab') {
      event.preventDefault();
      const target = event.currentTarget;
      const { selectionStart: a, selectionEnd: b } = target;
      const next = code.slice(0,a) + '    ' + code.slice(b);
      setCode(next);
      requestAnimationFrame(() => { try { target.setSelectionRange(a+4,a+4); } catch {} });
    }
  };
  return <section className="slcpp" aria-label="Laboratorium C++ — kompilator WebAssembly">
    <div className="slcpp-heading"><div><span className="slcpp-eyebrow">STUDYLAB · C++ 3.0</span><h3>Laboratorium C++</h3><p>Rzeczywista kompilacja i uruchamianie kodu lokalnie w przeglądarce. Clang 22 + WebAssembly (WASI).</p></div><span className="slcpp-chip">BEZ SERWERA</span></div>
    <div className="slcpp-modes" role="group" aria-label="Tryb programowania">
      <button type="button" className={view === 'free' ? 'active' : ''} aria-pressed={view === 'free'} onClick={() => switchTo('free')}>Własny program</button>
      <button type="button" className={view === 'task' ? 'active' : ''} aria-pressed={view === 'task'} onClick={() => switchTo('task')}>Zadania z testami</button>
    </div>
    {view === 'task' ? <div className="slcpp-task"><label>Zadanie<select disabled={active} value={taskId} onChange={e => switchTo('task', e.target.value)}>{TASKS.map(t => <option key={t.id} value={t.id}>{t.title}</option>)}</select></label><p>{task.description}</p><p className="slcpp-small">Wpisz samą funkcję, bez <code>main()</code>. Po kliknięciu „Uruchom testy” StudyLab skompiluje funkcję razem z przypadkami testowymi.</p></div> : <p className="slcpp-small">Własny program powinien zawierać funkcję <code>main()</code>. Dane dla <code>cin</code> wpisz poniżej przed uruchomieniem.</p>}
    <div className="slcpp-editor-bar"><span>● &nbsp;{view === 'free' ? 'main.cpp' : `${taskId}.cpp`}</span><label>Standard <select disabled={active} value={standard} onChange={e => setStandard(e.target.value)}>{STANDARDS.map(x=><option key={x} value={x}>{x.replace('gnu', 'C++')}</option>)}</select></label></div>
    <label className="slcpp-code-label" htmlFor="slcpp-code-input">Kod C++</label>
    <textarea id="slcpp-code-input" className="slcpp-editor" value={code} disabled={active} onChange={e => setCode(e.target.value)} onKeyDown={onCodeKeyDown} spellCheck={false} autoCapitalize="off" autoCorrect="off" aria-label="Edytor kodu C++" rows={15} />
    {view === 'free' ? <label className="slcpp-input-label">Dane wejściowe — stdin / cin<textarea value={stdin} disabled={active} onChange={e => setStdin(e.target.value)} spellCheck={false} rows={2} placeholder="np. 5 7" /></label> : <div className="slcpp-tests-hint">{task.tests.length} przypadków testowych · {showTip ? <span>{task.tip}</span> : <button type="button" onClick={() => setShowTip(true)}>Pokaż podpowiedź</button>}</div>}
    <div className="slcpp-actions">
      <button type="button" className="slcpp-primary" onClick={run} disabled={active}>{active ? 'Trwa kompilacja…' : view === 'task' ? '▶ Uruchom testy' : '▶ Uruchom kod'}</button>
      {active && <button type="button" className="slcpp-stop" onClick={() => terminate()}>■ Zatrzymaj</button>}
      <button type="button" className="slcpp-secondary" disabled={active} onClick={download}>↓ Pobierz .cpp</button>
      <button type="button" className="slcpp-secondary" disabled={active} onClick={() => { if (window.confirm('Zastąpić bieżący kod szablonem?')) { setCode(view === 'free' ? DEFAULT_PROGRAM : task.template); setResult(null); setMessage('Przywrócono przykładowy kod.'); } }}>Przywróć przykład</button>
    </div>
    <div className="slcpp-console" aria-live="polite"><div className="slcpp-console-header"><span>⌁ Konsola i diagnostyka</span><span className={`slcpp-state slcpp-${phase}`}>{active ? phase === 'loading' ? 'Ładowanie' : 'Kompilowanie / wykonywanie' : phase === 'done' ? 'Zakończono' : phase === 'error' || phase === 'timeout' ? 'Błąd' : phase === 'stopped' ? 'Zatrzymano' : 'Gotowość'}</span></div>
      {phase === 'loading' && <div className="slcpp-progress" role="progressbar" aria-valuenow={Math.round(progress*100)} aria-valuemin="0" aria-valuemax="100"><div style={{ width: `${Math.max(0,Math.min(100,progress*100))}%` }} /></div>}
      <p className="slcpp-status" role="status">{message}</p>
      {result && <><div className="slcpp-meta"><span>Kompilacja: {Number.isFinite(result.compileMs) ? Math.round(result.compileMs) + ' ms' : '—'}</span><span>Uruchomienie: {Number.isFinite(result.runMs) ? Math.round(result.runMs) + ' ms' : '—'}</span><span>Kod wyjścia: {result.exitCode ?? 'nie uruchomiono'}</span></div>{result.errors?.length > 0 && <div className="slcpp-block slcpp-error"><strong>Błędy kompilacji</strong><pre>{result.errors.join('\n')}</pre></div>}{result.stdout && <div className="slcpp-block"><strong>stdout</strong><pre>{result.stdout}</pre></div>}{result.stderr && <div className="slcpp-block slcpp-error"><strong>stderr</strong><pre>{result.stderr}</pre></div>}{!result.stdout && !result.stderr && !(result.errors?.length) && <p className="slcpp-small">Program nie wypisał nic do konsoli.</p>}{result.tests && <div className="slcpp-test-list"><h4>Testy automatyczne: {result.tests.filter(t=>t.pass).length}/{result.tests.length}</h4>{result.tests.map((test,i) => <div className={test.pass ? 'slcpp-pass' : 'slcpp-fail'} key={i}><span>{test.pass ? '✓' : '✕'} Test {i+1}: ({test.args})</span><span>oczekiwano: <code>{test.expected}</code> · otrzymano: <code>{test.received}</code></span></div>)}</div>}</>}
    </div>
    <p className="slcpp-disclaimer">Wykonywanie w odizolowanym Web Workerze; kod C++ nie jest przesyłany do zewnętrznego API. Pierwsze uruchomienie pobiera pliki kompilatora. Dane dla <code>cin</code> są podawane przed startem, nie podczas działania programu. Nie wszystkie biblioteki systemowe, wyjątki C++ i wielowątkowość są dostępne w WASI. Kod edytora jest zapisywany lokalnie na tym urządzeniu.</p>
  </section>;
}

export { makeHarness, readTestResults, TASKS, DEFAULT_PROGRAM };
