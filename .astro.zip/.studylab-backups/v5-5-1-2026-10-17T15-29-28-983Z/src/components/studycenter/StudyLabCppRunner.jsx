import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import './studylab-cpp-runner.css';

const DEFAULT_PROGRAM = `#include <iostream>
using namespace std;

int main() {
    int a, b;
    cout << "Podaj dwie liczby: ";
    cin >> a >> b;
    cout << "Suma: " << a + b << '\\n';
    if (a > b) {
        cout << "Pierwsza jest większa\\n";
    } else {
        cout << "Druga jest większa lub równa\\n";
    }
    return 0;
}
`;

const TASKS = [
  { id: 'sum', title: 'Suma liczb od 1 do n', description: 'Napisz funkcję int suma(int n). Dla n >= 0 zwróć sumę liczb całkowitych od 1 do n.', template: 'int suma(int n) {\n    int wynik = 0;\n    for (int i = 1; i <= n; i++) {\n        wynik += i;\n    }\n    return wynik;\n}\n', tip: 'Zacznij od int wynik = 0. Dodawaj kolejne liczby od 1 do n i zwróć wynik.', tests: [{ args: '0', expected: '0' }, { args: '1', expected: '1' }, { args: '3', expected: '6' }, { args: '10', expected: '55' }] },
  { id: 'even', title: 'Parzysta czy nie?', description: 'Napisz funkcję bool czyParzysta(int n).', template: 'bool czyParzysta(int n) {\n    return n % 2 == 0;\n}\n', tip: 'Jeśli n % 2 == 0, liczba jest parzysta. Zwróć wynik porównania.', tests: [{ args: '0', expected: '1' }, { args: '2', expected: '1' }, { args: '7', expected: '0' }, { args: '-4', expected: '1' }] },
  { id: 'max', title: 'Maksimum dwóch liczb', description: 'Napisz funkcję int maksimum(int a, int b).', template: 'int maksimum(int a, int b) {\n    if (a > b) {\n        return a;\n    }\n    return b;\n}\n', tip: 'Użyj if (a > b) return a; a w przeciwnym razie return b;', tests: [{ args: '2, 5', expected: '5' }, { args: '8, 3', expected: '8' }, { args: '4, 4', expected: '4' }, { args: '-7, -2', expected: '-2' }] },
  { id: 'factorial', title: 'Silnia', description: 'Napisz funkcję long long silnia(int n), przyjmując 0 <= n <= 20.', template: 'long long silnia(int n) {\n    long long wynik = 1;\n    for (int i = 2; i <= n; i++) {\n        wynik *= i;\n    }\n    return wynik;\n}\n', tip: 'Wynik rozpocznij od 1. Dla i od 2 do n mnoż wynik przez i.', tests: [{ args: '0', expected: '1' }, { args: '1', expected: '1' }, { args: '4', expected: '24' }, { args: '7', expected: '5040' }, { args: '10', expected: '3628800' }] },
];

const FUNCTION_NAMES = { sum: 'suma', even: 'czyParzysta', max: 'maksimum', factorial: 'silnia' };
const STANDARDS = ['gnu++11', 'gnu++14', 'gnu++17', 'gnu++20', 'gnu++23'];
const RUN_LIMIT_MS = 60000;
const safeLoad = (key, fallback) => { try { return localStorage.getItem(key) ?? fallback; } catch { return fallback; } };
const safeSave = (key, value) => { try { localStorage.setItem(key, value); } catch {} };
const codeKey = (view, id) => `studylab-cpp-wasm-v2:${view}:${id}`;

function makeHarness(code, task) {
  if (/\b(?:int|auto|void)\s+main\s*\(/.test(code)) throw new Error('W zadaniu wpisz tylko funkcję (bez main). StudyLab sam doda main() do testów.');
  const fname = FUNCTION_NAMES[task.id];
  if (!fname) throw new Error('Nieznane zadanie.');
  const tests = task.tests.map((item, index) => `    std::cout << "STUDYLAB_TEST_${index}:" << (${fname}(${item.args})) << "\\n";`).join('\n');
  return `${code}\n#include <iostream>\nint main() {\n${tests}\n    return 0;\n}\n`;
}
function readTestResults(stdout, task) {
  const outputs = new Map();
  for (const line of String(stdout).split(/\r?\n/)) {
    const m = line.trim().match(/^STUDYLAB_TEST_(\d+):(.*)$/);
    if (m) outputs.set(Number(m[1]), m[2].trim());
  }
  return task.tests.map((test, index) => ({ ...test, received: outputs.get(index) ?? 'brak wyniku', pass: outputs.get(index) === test.expected }));
}

function stripComments(source) {
  return source
    .replace(/\/\*[\s\S]*?\*\//g, '')
    .replace(/(^|[^:])\/\/.*$/gm, '$1');
}
function findMatchingBrace(source, openIndex) {
  let depth = 0;
  let quote = null;
  let escape = false;
  for (let i = openIndex; i < source.length; i += 1) {
    const ch = source[i];
    if (quote) {
      if (escape) { escape = false; continue; }
      if (ch === '\\') { escape = true; continue; }
      if (ch === quote) quote = null;
      continue;
    }
    if (ch === '"' || ch === "'") { quote = ch; continue; }
    if (ch === '{') depth += 1;
    if (ch === '}') {
      depth -= 1;
      if (depth === 0) return i;
    }
  }
  return -1;
}
function extractFlowSource(source, view, task) {
  const clean = stripComments(source);
  if (view === 'free') {
    const match = clean.match(/\b(?:int|auto|void)\s+main\s*\([^)]*\)\s*\{/m);
    if (!match || match.index == null) throw new Error('Nie znaleziono funkcji main(). Schemat blokowy działa dla pełnych programów z main().');
    const openIndex = clean.indexOf('{', match.index);
    const closeIndex = findMatchingBrace(clean, openIndex);
    if (closeIndex === -1) throw new Error('Nie znaleziono kończącej klamry funkcji main().');
    return { body: clean.slice(openIndex + 1, closeIndex), label: 'main()' };
  }
  const fn = FUNCTION_NAMES[task.id] || task.id;
  const match = clean.match(new RegExp(`\\b${fn}\\s*\\([^)]*\\)\\s*\\{`, 'm'));
  if (!match || match.index == null) throw new Error('Nie znaleziono funkcji zadania.');
  const openIndex = clean.indexOf('{', match.index);
  const closeIndex = findMatchingBrace(clean, openIndex);
  if (closeIndex === -1) throw new Error('Nie znaleziono kończącej klamry funkcji zadania.');
  return { body: clean.slice(openIndex + 1, closeIndex), label: `${fn}()` };
}
function tokenizeFlow(body) {
  const tokens = [];
  let current = '';
  let parenDepth = 0;
  let quote = null;
  let escape = false;
  for (let i = 0; i < body.length; i += 1) {
    const ch = body[i];
    if (quote) {
      current += ch;
      if (escape) { escape = false; continue; }
      if (ch === '\\') { escape = true; continue; }
      if (ch === quote) quote = null;
      continue;
    }
    if (ch === '"' || ch === "'") { quote = ch; current += ch; continue; }
    if (ch === '(') { parenDepth += 1; current += ch; continue; }
    if (ch === ')') { parenDepth = Math.max(0, parenDepth - 1); current += ch; continue; }
    if ((ch === '{' || ch === '}') && parenDepth === 0) {
      if (current.trim()) tokens.push(current.trim());
      tokens.push(ch);
      current = '';
      continue;
    }
    if (ch === ';' && parenDepth === 0) {
      current += ';';
      if (current.trim()) tokens.push(current.trim());
      current = '';
      continue;
    }
    current += ch;
  }
  if (current.trim()) tokens.push(current.trim());
  const expanded = [];
  for (const token of tokens) {
    const trimmed = token.trim();
    if (/^else\s+if\b/.test(trimmed)) {
      expanded.push('else');
      expanded.push(trimmed.replace(/^else\s+/, ''));
    } else expanded.push(trimmed);
  }
  return expanded.filter(Boolean);
}
function nodeFromStatement(statement) {
  const text = statement.trim().replace(/;+$/, ';');
  if (!text) return null;
  if (/^return\b/.test(text)) return { type: 'return', text };
  if (/\bcin\s*>>/.test(text)) return { type: 'input', text };
  if (/\b(?:cout|printf)\b/.test(text)) return { type: 'output', text };
  return { type: 'process', text };
}
function parseSequence(tokens, index = 0) {
  const items = [];
  let i = index;
  while (i < tokens.length) {
    const token = tokens[i];
    if (token === '}') return { items, index: i + 1 };
    if (token === '{') {
      const nested = parseSequence(tokens, i + 1);
      items.push(...nested.items);
      i = nested.index;
      continue;
    }
    if (/^if\s*\(/.test(token)) {
      let yes = [];
      i += 1;
      if (tokens[i] === '{') {
        const parsed = parseSequence(tokens, i + 1);
        yes = parsed.items;
        i = parsed.index;
      } else if (i < tokens.length) {
        if (/^if\s*\(/.test(tokens[i])) {
          const nested = parseSequence(tokens.slice(i, i + 1));
          yes = nested.items;
          i += 1;
        } else {
          const single = nodeFromStatement(tokens[i]);
          if (single) yes = [single];
          i += 1;
        }
      }
      let no = [];
      if (tokens[i] && /^else\b/.test(tokens[i])) {
        i += 1;
        if (tokens[i] === '{') {
          const parsedElse = parseSequence(tokens, i + 1);
          no = parsedElse.items;
          i = parsedElse.index;
        } else if (tokens[i]) {
          if (/^if\s*\(/.test(tokens[i])) {
            const parsedElseIf = parseSequence(tokens, i);
            no = parsedElseIf.items;
            i = parsedElseIf.index;
          } else {
            const singleElse = nodeFromStatement(tokens[i]);
            if (singleElse) no = [singleElse];
            i += 1;
          }
        }
      }
      items.push({ type: 'decision', text: token, yes, no });
      continue;
    }
    if (/^(for|while)\s*\(/.test(token)) {
      const loopType = token.startsWith('for') ? 'for' : 'while';
      let body = [];
      i += 1;
      if (tokens[i] === '{') {
        const parsed = parseSequence(tokens, i + 1);
        body = parsed.items;
        i = parsed.index;
      } else if (tokens[i]) {
        const single = nodeFromStatement(tokens[i]);
        if (single) body = [single];
        i += 1;
      }
      items.push({ type: 'loop', loopType, text: token, body });
      continue;
    }
    if (/^do\b/.test(token)) {
      let body = [];
      i += 1;
      if (tokens[i] === '{') {
        const parsed = parseSequence(tokens, i + 1);
        body = parsed.items;
        i = parsed.index;
      } else if (tokens[i]) {
        const single = nodeFromStatement(tokens[i]);
        if (single) body = [single];
        i += 1;
      }
      const condition = tokens[i] && /^while\s*\(/.test(tokens[i]) ? tokens[i] : 'while (...)';
      if (tokens[i] && /^while\s*\(/.test(tokens[i])) i += 1;
      items.push({ type: 'loop', loopType: 'do-while', text: condition, body });
      continue;
    }
    const simple = nodeFromStatement(token);
    if (simple) items.push(simple);
    i += 1;
  }
  return { items, index: i };
}
function wrapText(text, limit = 24) {
  const raw = String(text || '').replace(/\s+/g, ' ').trim();
  if (!raw) return [''];
  const words = raw.split(' ');
  const lines = [];
  let current = '';
  for (const word of words) {
    if (!current) { current = word; continue; }
    if ((current + ' ' + word).length <= limit) current += ' ' + word;
    else { lines.push(current); current = word; }
  }
  if (current) lines.push(current);
  return lines.slice(0, 6);
}
function simplifyLabel(text) {
  return String(text || '')
    .replace(/^\s+|\s+$/g, '')
    .replace(/\bstd::/g, '')
    .replace(/\s+/g, ' ');
}
function createSimpleNode(kind, text, x, y) {
  const map = {
    start: { shape: 'terminal', w: 210, h: 54 },
    end: { shape: 'terminal', w: 210, h: 54 },
    process: { shape: 'process', w: 240, h: 64 },
    input: { shape: 'io', w: 250, h: 64 },
    output: { shape: 'io', w: 250, h: 64 },
    return: { shape: 'process', w: 240, h: 64 },
    decision: { shape: 'decision', w: 220, h: 88 },
  }[kind] || { shape: 'process', w: 240, h: 64 };
  return { kind, text: simplifyLabel(text), x, y, ...map };
}
function buildPolyline(points) {
  if (!points.length) return '';
  const [first, ...rest] = points;
  return `M ${first.x} ${first.y} ` + rest.map((point) => `L ${point.x} ${point.y}`).join(' ');
}
function addVerticalEdge(edges, from, to, label = '') {
  edges.push({ d: buildPolyline([{ x: from.x, y: from.y }, { x: to.x, y: to.y }]), label, lx: from.x + 8, ly: (from.y + to.y) / 2 - 6 });
}
function addOrthogonalEdge(edges, from, to, label = '', bendX = null) {
  const viaX = bendX ?? from.x;
  const points = [{ x: from.x, y: from.y }, { x: viaX, y: from.y }, { x: viaX, y: to.y }, { x: to.x, y: to.y }];
  edges.push({ d: buildPolyline(points), label, lx: viaX + 8, ly: Math.min(from.y, to.y) + 18 });
}
function layoutSequence(items, x, startY, nodes, edges, settings) {
  let y = startY;
  let firstEntry = null;
  let previousExit = null;
  for (const item of items) {
    const laid = layoutItem(item, x, y, nodes, edges, settings);
    if (!firstEntry) firstEntry = laid.entry;
    if (previousExit) addVerticalEdge(edges, previousExit, laid.entry);
    previousExit = laid.exit;
    y = laid.nextY;
  }
  return { entry: firstEntry ?? { x, y: startY }, exit: previousExit ?? { x, y: startY }, nextY: y };
}
function layoutItem(item, x, y, nodes, edges, settings) {
  if (!item) return { entry: { x, y }, exit: { x, y }, nextY: y };
  if (item.type === 'process' || item.type === 'input' || item.type === 'output' || item.type === 'return') {
    const node = createSimpleNode(item.type, item.text, x, y);
    nodes.push(node);
    return { entry: { x, y }, exit: { x, y: y + node.h }, nextY: y + node.h + settings.gapY };
  }
  if (item.type === 'decision') {
    const node = createSimpleNode('decision', item.text, x, y);
    nodes.push(node);
    const branchY = y + node.h + 36;
    const yesItems = item.yes?.length ? item.yes : [{ type: 'process', text: 'brak instrukcji' }];
    const noItems = item.no?.length ? item.no : [{ type: 'process', text: 'brak instrukcji' }];
    const yes = layoutSequence(yesItems, x - settings.branchOffset, branchY, nodes, edges, settings);
    const no = layoutSequence(noItems, x + settings.branchOffset, branchY, nodes, edges, settings);
    addOrthogonalEdge(edges, { x, y: y + node.h }, yes.entry, 'TAK', x - settings.branchOffset);
    addOrthogonalEdge(edges, { x, y: y + node.h }, no.entry, 'NIE', x + settings.branchOffset);
    const mergeY = Math.max(yes.exit.y, no.exit.y) + 36;
    addOrthogonalEdge(edges, yes.exit, { x, y: mergeY }, '', x - settings.branchOffset);
    addOrthogonalEdge(edges, no.exit, { x, y: mergeY }, '', x + settings.branchOffset);
    return { entry: { x, y }, exit: { x, y: mergeY }, nextY: mergeY + settings.gapY };
  }
  if (item.type === 'loop') {
    const node = createSimpleNode('decision', item.text, x, y);
    nodes.push(node);
    const bodyItems = item.body?.length ? item.body : [{ type: 'process', text: 'brak instrukcji' }];
    const body = layoutSequence(bodyItems, x + settings.loopOffset, y + node.h + 36, nodes, edges, settings);
    addOrthogonalEdge(edges, { x, y: y + node.h }, body.entry, 'TAK', x + settings.loopOffset);
    const loopReturnY = y + Math.round(node.h / 2);
    edges.push({
      d: buildPolyline([
        { x: body.exit.x, y: body.exit.y },
        { x: body.exit.x + 42, y: body.exit.y },
        { x: body.exit.x + 42, y: loopReturnY },
        { x: x + 110, y: loopReturnY },
      ]),
      label: item.loopType === 'do-while' ? 'warunek' : 'następna iteracja',
      lx: body.exit.x + 50,
      ly: loopReturnY - 8,
    });
    const exitY = Math.max(body.exit.y, y + node.h) + 44;
    addVerticalEdge(edges, { x, y: y + node.h }, { x, y: exitY }, 'NIE');
    return { entry: { x, y }, exit: { x, y: exitY }, nextY: exitY + settings.gapY };
  }
  if (item.items) return layoutSequence(item.items, x, y, nodes, edges, settings);
  const fallback = createSimpleNode('process', item.text || 'instrukcja', x, y);
  nodes.push(fallback);
  return { entry: { x, y }, exit: { x, y: y + fallback.h }, nextY: y + fallback.h + settings.gapY };
}
function createFlowModel(source, view, task) {
  const settings = { centerX: 490, gapY: 42, branchOffset: 220, loopOffset: 240 };
  const extracted = extractFlowSource(source, view, task);
  const tokens = tokenizeFlow(extracted.body);
  const parsed = parseSequence(tokens);
  const nodes = [];
  const edges = [];
  const start = createSimpleNode('start', `START — ${extracted.label}`, settings.centerX, 28);
  nodes.push(start);
  const sequence = parsed.items.length
    ? layoutSequence(parsed.items, settings.centerX, 118, nodes, edges, settings)
    : layoutSequence([{ type: 'process', text: 'brak instrukcji' }], settings.centerX, 118, nodes, edges, settings);
  addVerticalEdge(edges, { x: settings.centerX, y: start.y + start.h }, sequence.entry);
  const end = createSimpleNode('end', 'STOP', settings.centerX, sequence.exit.y + 42);
  nodes.push(end);
  addVerticalEdge(edges, sequence.exit, { x: settings.centerX, y: end.y });
  const width = 980;
  const height = end.y + end.h + 28;
  return { nodes, edges, width, height, title: extracted.label };
}

function Shape({ node }) {
  const lines = wrapText(node.text, node.shape === 'decision' ? 20 : 24);
  const x = node.x - node.w / 2;
  const y = node.y;
  const textY = y + node.h / 2 - ((lines.length - 1) * 9);
  const textClass = `slcpp-flow-text slcpp-flow-text-${node.kind}`;
  if (node.shape === 'terminal') {
    return <g><rect x={x} y={y} width={node.w} height={node.h} rx="24" ry="24" className={`slcpp-flow-node slcpp-flow-${node.kind}`} /><text x={node.x} y={textY} textAnchor="middle" className={textClass}>{lines.map((line, index) => <tspan key={index} x={node.x} dy={index === 0 ? 0 : 18}>{line}</tspan>)}</text></g>;
  }
  if (node.shape === 'io') {
    const skew = 18;
    const points = `${x + skew},${y} ${x + node.w},${y} ${x + node.w - skew},${y + node.h} ${x},${y + node.h}`;
    return <g><polygon points={points} className={`slcpp-flow-node slcpp-flow-${node.kind}`} /><text x={node.x} y={textY} textAnchor="middle" className={textClass}>{lines.map((line, index) => <tspan key={index} x={node.x} dy={index === 0 ? 0 : 18}>{line}</tspan>)}</text></g>;
  }
  if (node.shape === 'decision') {
    const points = `${node.x},${y} ${x + node.w},${y + node.h / 2} ${node.x},${y + node.h} ${x},${y + node.h / 2}`;
    return <g><polygon points={points} className={`slcpp-flow-node slcpp-flow-${node.kind}`} /><text x={node.x} y={textY} textAnchor="middle" className={textClass}>{lines.map((line, index) => <tspan key={index} x={node.x} dy={index === 0 ? 0 : 18}>{line}</tspan>)}</text></g>;
  }
  return <g><rect x={x} y={y} width={node.w} height={node.h} rx="14" ry="14" className={`slcpp-flow-node slcpp-flow-${node.kind}`} /><text x={node.x} y={textY} textAnchor="middle" className={textClass}>{lines.map((line, index) => <tspan key={index} x={node.x} dy={index === 0 ? 0 : 18}>{line}</tspan>)}</text></g>;
}

function FlowchartPanel({ flow, sourceName, svgRef, onDownloadSvg, onDownloadPng }) {
  return <div className="slcpp-flow-wrap">
    <div className="slcpp-flow-header">
      <div>
        <h4>Schemat blokowy</h4>
        <p>Schemat aktualizuje się automatycznie na podstawie kodu z pliku <strong>{sourceName}</strong>.</p>
      </div>
      <div className="slcpp-flow-actions">
        <button type="button" className="slcpp-secondary" onClick={onDownloadSvg} disabled={!flow || flow.error}>↓ Pobierz SVG</button>
        <button type="button" className="slcpp-secondary" onClick={onDownloadPng} disabled={!flow || flow.error}>↓ Pobierz PNG</button>
      </div>
    </div>
    {flow?.error ? <div className="slcpp-flow-empty"><strong>Nie udało się wygenerować schematu.</strong><p>{flow.error}</p><p className="slcpp-small">Najlepiej działa dla prostych programów edukacyjnych z <code>main()</code>, instrukcjami <code>cin</code>, <code>cout</code>, <code>if</code>, <code>for</code>, <code>while</code> i <code>return</code>.</p></div> : <div className="slcpp-flow-canvas"><svg ref={svgRef} className="slcpp-flow-svg" viewBox={`0 0 ${flow.width} ${flow.height}`} role="img" aria-label="Automatycznie wygenerowany schemat blokowy programu C++"><defs><marker id="slcpp-arrow" viewBox="0 0 10 10" refX="8.5" refY="5" markerWidth="8" markerHeight="8" orient="auto-start-reverse"><path d="M 0 0 L 10 5 L 0 10 z" fill="#94aecd" /></marker></defs><rect x="0" y="0" width={flow.width} height={flow.height} rx="18" ry="18" className="slcpp-flow-bg" />{flow.edges.map((edge, index) => <g key={index}><path d={edge.d} className="slcpp-flow-edge" markerEnd="url(#slcpp-arrow)" />{edge.label ? <text x={edge.lx} y={edge.ly} className="slcpp-flow-label">{edge.label}</text> : null}</g>)}{flow.nodes.map((node, index) => <Shape key={`${node.kind}-${index}-${node.text}`} node={node} />)}</svg></div>}
  </div>;
}

export default function StudyLabCppRunner({ onAttempt }) {
  const [view, setView] = useState('free');
  const [taskId, setTaskId] = useState('sum');
  const [code, setCode] = useState(() => safeLoad(codeKey('free', 'main'), DEFAULT_PROGRAM));
  const [stdin, setStdin] = useState(() => safeLoad('studylab-cpp-wasm-v2:stdin', '5 7\n'));
  const [standard, setStandard] = useState(() => safeLoad('studylab-cpp-wasm-v2:standard', 'gnu++17'));
  const [phase, setPhase] = useState('idle');
  const [progress, setProgress] = useState(0);
  const [message, setMessage] = useState('Wybierz „Uruchom kod”, aby skompilować go w przeglądarce.');
  const [result, setResult] = useState(null);
  const [showTip, setShowTip] = useState(false);
  const workerRef = useRef(null);
  const timerRef = useRef(null);
  const serialRef = useRef(0);
  const currentRef = useRef(null);
  const onAttemptRef = useRef(onAttempt);
  const svgRef = useRef(null);
  onAttemptRef.current = onAttempt;
  const active = ['loading', 'compiling', 'running'].includes(phase);
  const task = TASKS.find((t) => t.id === taskId) || TASKS[0];

  useEffect(() => { safeSave(codeKey(view, view === 'free' ? 'main' : taskId), code); }, [code, view, taskId]);
  useEffect(() => { safeSave('studylab-cpp-wasm-v2:stdin', stdin); }, [stdin]);
  useEffect(() => { safeSave('studylab-cpp-wasm-v2:standard', standard); }, [standard]);
  useEffect(() => () => { serialRef.current += 1; clearTimeout(timerRef.current); workerRef.current?.terminate(); workerRef.current = null; }, []);

  const terminate = useCallback((status = 'stopped') => {
    serialRef.current += 1;
    clearTimeout(timerRef.current);
    workerRef.current?.terminate();
    workerRef.current = null;
    currentRef.current = null;
    setPhase(status);
    setMessage(status === 'timeout'
      ? 'Przekroczono limit 60 sekund od rozpoczęcia kompilacji. Proces został zatrzymany. Możesz uruchomić go ponownie.'
      : 'Zatrzymano kompilację lub program.');
  }, []);

  const switchTo = (nextView, nextTaskId = taskId) => {
    if (active) terminate();
    setView(nextView);
    setTaskId(nextTaskId);
    const chosen = TASKS.find((t) => t.id === nextTaskId) || TASKS[0];
    setCode(safeLoad(codeKey(nextView, nextView === 'free' ? 'main' : nextTaskId), nextView === 'free' ? DEFAULT_PROGRAM : chosen.template));
    setShowTip(false);
    setResult(null);
    setPhase('idle');
    setMessage('Kod gotowy do uruchomienia.');
  };

  const run = useCallback(() => {
    if (active) return;
    if (!code.trim()) { setPhase('error'); setMessage('Najpierw wpisz kod C++.'); return; }
    let source = code;
    if (view === 'task') {
      try { source = makeHarness(code, task); }
      catch (e) { setPhase('error'); setMessage(e.message); return; }
    }
    const runId = serialRef.current + 1;
    serialRef.current = runId;
    clearTimeout(timerRef.current);
    workerRef.current?.terminate();
    workerRef.current = null;
    currentRef.current = { view, task, onAttempt: onAttemptRef.current };
    setResult(null);
    setPhase('loading');
    setProgress(0);
    setMessage('Przygotowywanie kompilatora Clang w WebAssembly… przy pierwszym uruchomieniu pobierze około 29 MB.');
    try {
      const base = import.meta.env.BASE_URL || '/';
      const workerUrl = new URL(`${base.replace(/\/$/, '')}/clang/studylab-cpp.worker.js`, window.location.origin);
      const worker = workerRef.current || new Worker(workerUrl);
      workerRef.current = worker;
      worker.onmessage = (event) => {
        if (serialRef.current !== runId) return;
        const msg = event.data || {};
        if (msg.type === 'progress') {
          setProgress(Number(msg.value) || 0);
          setMessage('Pobieranie i inicjalizacja kompilatora: ' + Math.round((Number(msg.value) || 0) * 100) + '%');
        } else if (msg.type === 'ready') {
          setPhase('compiling');
          setMessage('Kompilowanie kodu przez Clang…');
          clearTimeout(timerRef.current);
          timerRef.current = setTimeout(() => terminate('timeout'), RUN_LIMIT_MS);
        } else if (msg.type === 'finished') {
          clearTimeout(timerRef.current);
          const data = msg.result || {};
          const compiled = Number.isInteger(data.exitCode);
          const tests = currentRef.current?.view === 'task' && compiled ? readTestResults(data.stdout, currentRef.current.task) : null;
          const allPass = Array.isArray(tests) && tests.every((item) => item.pass);
          setResult({ ...data, tests, allPass });
          setPhase(compiled ? 'done' : 'error');
          setMessage(!compiled ? 'Błąd kompilacji lub linkowania — sprawdź komunikaty poniżej.' : tests ? `Testy: ${tests.filter((t) => t.pass).length}/${tests.length} poprawnych.` : 'Program wykonany. Kod wyjścia: ' + data.exitCode);
          if (tests && typeof currentRef.current?.onAttempt === 'function') {
            const info = currentRef.current;
            try {
              info.onAttempt({ id: `plus-cpp-wasm-${info.task.id}-${Date.now()}-${runId}`, subject: 'cpp', topic: `plus-cpp-wasm-${info.task.id}`, question: info.task.description, given: tests.map((t, i) => `${i + 1}:${t.received}`).join(', ').slice(0, 400), answer: tests.map((t, i) => `${i + 1}:${t.expected}`).join(', ').slice(0, 400), why: `Rzeczywisty Clang/WASM, testy: ${tests.filter((t) => t.pass).length}/${tests.length}`, ok: allPass, mode: 'plus-cpp-wasm', hints: showTip ? 1 : 0, date: Date.now() });
            } catch {}
          }
        } else if (msg.type === 'failed') {
          clearTimeout(timerRef.current);
          setPhase('error');
          setMessage(String(msg.message || 'Nie udało się uruchomić kompilatora.'));
        }
      };
      worker.onerror = (event) => {
        if (serialRef.current !== runId) return;
        clearTimeout(timerRef.current);
        worker.terminate();
        if (workerRef.current === worker) workerRef.current = null;
        setPhase('error');
        setMessage('Błąd ładowania Workera: ' + (event.message || 'Sprawdź, czy public/clang/ zostało zainstalowane.'));
      };
      worker.postMessage({ type: 'run', source, stdin: view === 'task' ? '' : stdin, standard });
    } catch (e) {
      clearTimeout(timerRef.current);
      workerRef.current?.terminate();
      workerRef.current = null;
      setPhase('error');
      setMessage('Nie można uruchomić kompilatora: ' + (e.message || String(e)));
    }
  }, [active, code, view, task, stdin, standard, terminate, showTip]);

  const downloadCode = () => {
    const blob = new Blob([code], { type: 'text/x-c++src;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = view === 'free' ? 'main.cpp' : `${taskId}.cpp`;
    document.body.appendChild(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  };
  const onCodeKeyDown = (event) => {
    if ((event.ctrlKey || event.metaKey) && event.key === 'Enter') {
      event.preventDefault();
      run();
    }
    if (event.key === 'Tab') {
      event.preventDefault();
      const target = event.currentTarget;
      const { selectionStart: a, selectionEnd: b } = target;
      const next = code.slice(0, a) + '    ' + code.slice(b);
      setCode(next);
      requestAnimationFrame(() => { try { target.setSelectionRange(a + 4, a + 4); } catch {} });
    }
  };

  const flow = useMemo(() => {
    try {
      return createFlowModel(code, view, task);
    } catch (error) {
      return { error: error.message || String(error) };
    }
  }, [code, view, task]);

  const downloadSvg = () => {
    const svg = svgRef.current;
    if (!svg || !flow || flow.error) return;
    const clone = svg.cloneNode(true);
    clone.setAttribute('xmlns', 'http://www.w3.org/2000/svg');
    const content = `<?xml version="1.0" encoding="UTF-8"?>\n${new XMLSerializer().serializeToString(clone)}`;
    const blob = new Blob([content], { type: 'image/svg+xml;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${view === 'free' ? 'main' : taskId}-schemat.svg`;
    document.body.appendChild(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  };
  const downloadPng = () => {
    const svg = svgRef.current;
    if (!svg || !flow || flow.error) return;
    const clone = svg.cloneNode(true);
    clone.setAttribute('xmlns', 'http://www.w3.org/2000/svg');
    const content = new XMLSerializer().serializeToString(clone);
    const blob = new Blob([content], { type: 'image/svg+xml;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const img = new Image();
    img.onload = () => {
      const canvas = document.createElement('canvas');
      canvas.width = flow.width * 2;
      canvas.height = flow.height * 2;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;
      ctx.scale(2, 2);
      ctx.fillStyle = '#061019';
      ctx.fillRect(0, 0, flow.width, flow.height);
      ctx.drawImage(img, 0, 0, flow.width, flow.height);
      URL.revokeObjectURL(url);
      canvas.toBlob((pngBlob) => {
        if (!pngBlob) return;
        const pngUrl = URL.createObjectURL(pngBlob);
        const link = document.createElement('a');
        link.href = pngUrl;
        link.download = `${view === 'free' ? 'main' : taskId}-schemat.png`;
        document.body.appendChild(link);
        link.click();
        link.remove();
        setTimeout(() => URL.revokeObjectURL(pngUrl), 1000);
      }, 'image/png');
    };
    img.src = url;
  };

  return <section className="slcpp" aria-label="Laboratorium C++ — kompilator WebAssembly i schematy blokowe">
    <div className="slcpp-heading"><div><span className="slcpp-eyebrow">STUDYLAB · C++ 5.5</span><h3>Laboratorium C++</h3><p>Rzeczywista kompilacja i uruchamianie kodu lokalnie w przeglądarce. Dodatkowo — automatyczny schemat blokowy widoczny od razu na stronie.</p></div><span className="slcpp-chip">KOD + SCHEMAT</span></div>
    <div className="slcpp-modes" role="group" aria-label="Tryb programowania">
      <button type="button" className={view === 'free' ? 'active' : ''} aria-pressed={view === 'free'} onClick={() => switchTo('free')}>Własny program</button>
      <button type="button" className={view === 'task' ? 'active' : ''} aria-pressed={view === 'task'} onClick={() => switchTo('task')}>Zadania z testami</button>
    </div>
    {view === 'task'
      ? <div className="slcpp-task"><label>Zadanie<select disabled={active} value={taskId} onChange={(e) => switchTo('task', e.target.value)}>{TASKS.map((t) => <option key={t.id} value={t.id}>{t.title}</option>)}</select></label><p>{task.description}</p><p className="slcpp-small">Wpisz samą funkcję, bez <code>main()</code>. Po kliknięciu „Uruchom testy” StudyLab skompiluje funkcję razem z przypadkami testowymi.</p></div>
      : <p className="slcpp-small">Własny program powinien zawierać funkcję <code>main()</code>. Dane dla <code>cin</code> wpisz poniżej przed uruchomieniem. Schemat blokowy aktualizuje się automatycznie, gdy zmieniasz kod.</p>}
    <div className="slcpp-editor-bar"><span>● &nbsp;{view === 'free' ? 'main.cpp' : `${taskId}.cpp`}</span><label>Standard <select disabled={active} value={standard} onChange={(e) => setStandard(e.target.value)}>{STANDARDS.map((x) => <option key={x} value={x}>{x.replace('gnu', 'C++')}</option>)}</select></label></div>
    <label className="slcpp-code-label" htmlFor="slcpp-code-input">Kod C++</label>
    <textarea id="slcpp-code-input" className="slcpp-editor" value={code} disabled={active} onChange={(e) => setCode(e.target.value)} onKeyDown={onCodeKeyDown} spellCheck={false} autoCapitalize="off" autoCorrect="off" aria-label="Edytor kodu C++" rows={15} />
    {view === 'free'
      ? <label className="slcpp-input-label">Dane wejściowe — stdin / cin<textarea value={stdin} disabled={active} onChange={(e) => setStdin(e.target.value)} spellCheck={false} rows={2} placeholder="np. 5 7" /></label>
      : <div className="slcpp-tests-hint">{task.tests.length} przypadków testowych · {showTip ? <span>{task.tip}</span> : <button type="button" onClick={() => setShowTip(true)}>Pokaż podpowiedź</button>}</div>}
    <div className="slcpp-actions">
      <button type="button" className="slcpp-primary" onClick={run} disabled={active}>{active ? 'Trwa kompilacja…' : view === 'task' ? '▶ Uruchom testy' : '▶ Uruchom kod'}</button>
      {active ? <button type="button" className="slcpp-stop" onClick={() => terminate()}>■ Zatrzymaj</button> : null}
      <button type="button" className="slcpp-secondary" disabled={active} onClick={downloadCode}>↓ Pobierz .cpp</button>
      <button type="button" className="slcpp-secondary" disabled={active} onClick={() => { if (window.confirm('Zastąpić bieżący kod szablonem?')) { setCode(view === 'free' ? DEFAULT_PROGRAM : task.template); setResult(null); setMessage('Przywrócono przykładowy kod.'); } }}>Przywróć przykład</button>
    </div>
    <div className="slcpp-lab-grid">
      <div className="slcpp-console" aria-live="polite"><div className="slcpp-console-header"><span>⌁ Konsola i diagnostyka</span><span className={`slcpp-state slcpp-${phase}`}>{active ? phase === 'loading' ? 'Ładowanie' : 'Kompilowanie / wykonywanie' : phase === 'done' ? 'Zakończono' : phase === 'error' || phase === 'timeout' ? 'Błąd' : phase === 'stopped' ? 'Zatrzymano' : 'Gotowość'}</span></div>
        {phase === 'loading' ? <div className="slcpp-progress" role="progressbar" aria-valuenow={Math.round(progress * 100)} aria-valuemin="0" aria-valuemax="100"><div style={{ width: `${Math.max(0, Math.min(100, progress * 100))}%` }} /></div> : null}
        <p className="slcpp-status" role="status">{message}</p>
        {result ? <><div className="slcpp-meta"><span>Kompilacja: {Number.isFinite(result.compileMs) ? Math.round(result.compileMs) + ' ms' : '—'}</span><span>Uruchomienie: {Number.isFinite(result.runMs) ? Math.round(result.runMs) + ' ms' : '—'}</span><span>Kod wyjścia: {result.exitCode ?? 'nie uruchomiono'}</span></div>{result.errors?.length > 0 ? <div className="slcpp-block slcpp-error"><strong>Błędy kompilacji</strong><pre>{result.errors.join('\n')}</pre></div> : null}{result.stdout ? <div className="slcpp-block"><strong>stdout</strong><pre>{result.stdout}</pre></div> : null}{result.stderr ? <div className="slcpp-block slcpp-error"><strong>stderr</strong><pre>{result.stderr}</pre></div> : null}{!result.stdout && !result.stderr && !(result.errors?.length) ? <p className="slcpp-small">Program nie wypisał nic do konsoli.</p> : null}{result.tests ? <div className="slcpp-test-list"><h4>Testy automatyczne: {result.tests.filter((t) => t.pass).length}/{result.tests.length}</h4>{result.tests.map((test, i) => <div className={test.pass ? 'slcpp-pass' : 'slcpp-fail'} key={i}><span>{test.pass ? '✓' : '✕'} Test {i + 1}: ({test.args})</span><span>oczekiwano: <code>{test.expected}</code> · otrzymano: <code>{test.received}</code></span></div>)}</div> : null}</> : null}
      </div>
      <FlowchartPanel flow={flow} sourceName={view === 'free' ? 'main.cpp' : `${taskId}.cpp`} svgRef={svgRef} onDownloadSvg={downloadSvg} onDownloadPng={downloadPng} />
    </div>
    <p className="slcpp-disclaimer">Wykonywanie w odizolowanym Web Workerze; kod C++ nie jest przesyłany do zewnętrznego API. Schemat blokowy generuje się lokalnie w przeglądarce i najlepiej działa dla prostych, edukacyjnych programów lub funkcji. Dane dla <code>cin</code> są podawane przed startem, nie podczas działania programu. Nie wszystkie biblioteki systemowe, wyjątki C++ i wielowątkowość są dostępne w WASI. Kod edytora jest zapisywany lokalnie na tym urządzeniu.</p>
  </section>;
}

export { makeHarness, readTestResults, TASKS, DEFAULT_PROGRAM, createFlowModel, tokenizeFlow, extractFlowSource };
